﻿using System;

namespace WebElectronicCashCounter.Models
{
    internal class keyAttribute : Attribute
    {
    }
}